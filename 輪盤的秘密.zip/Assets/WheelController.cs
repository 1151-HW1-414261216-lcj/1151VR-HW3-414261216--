using UnityEngine;

public class WheelController : MonoBehaviour
{
    private float currentSpeed = 0f;
    private float maxSpeed = 1000f;   // 最大旋轉速度
    private bool isSpinning = false;
    private float deceleration = 300f; // 減速率

    void Update()
    {
        // 按下空白鍵開始旋轉
        if (Input.GetKeyDown(KeyCode.Space) && !isSpinning)
        {
            currentSpeed = maxSpeed;
            isSpinning = true;

            // 如果有掛載 Audio Source 且有放音效，開始轉時順便播音效
            AudioSource audioSource = GetComponent<AudioSource>();
            if (audioSource != null && audioSource.clip != null)
            {
                audioSource.Play();
            }
        }

        // 如果正在旋轉，進行減速直到停止
        if (isSpinning)
        {
            transform.Rotate(0, 0, currentSpeed * Time.deltaTime);
            currentSpeed -= deceleration * Time.deltaTime;

            if (currentSpeed <= 0)
            {
                currentSpeed = 0;
                isSpinning = false;
            }
        }
    }
}